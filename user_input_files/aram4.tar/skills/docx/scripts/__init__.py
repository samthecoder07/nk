# Make scripts directory a package for relative imports in tests
